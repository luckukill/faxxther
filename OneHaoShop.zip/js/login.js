$(function(){
	//鼠标悬浮显示菜单
	function showList(){
		var $list=$(".listlook");
		var $look=$(".look");
		$look.hover(function(){
			$list.show();
		},function(){
			$list.hide();
		})
	}
	showList();
	
});
