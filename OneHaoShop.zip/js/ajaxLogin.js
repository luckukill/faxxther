$(function(){
	$("input[type=button]").click(function(){
		var uname=$("#uname").val();
		var pass=$("#pass").val();
		$.ajax({
			"url":"ajaxphp/ajaxTest.html",
			"type":"get",
			"dataType":"json",
			"data":"#",
			"success":function(json){
				$.each(json, function(i) {
					if(uname==""||uname==null){
						alert("请输入用户名！");
						return false;
					}else if(json[i].userName!=uname){
						alert("用户名不存在！");
						return false;
					}else if(pass==""||pass==null){
						alert("请输入密码！");
						return false;
					}else if(json[i].pass!=pass){
						alert("密码错误！");
						return false;
					}else{
						alert("登录成功");
						location.href="index.html";
					}
				});
			},
		});
	})
})
