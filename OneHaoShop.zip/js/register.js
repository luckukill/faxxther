$(function(){
	//控制表单不合法提交
	function checkFormData(){
		$("#btn").click(function(){
			var uname=document.getElementById("uname");
			if(uname.validity.valueMissing==true){
				uname.setCustomValidity("请输入用户名！");
			}else if(uname.validity.patternMismatch==true){
				uname.setCustomValidity("用户名为4—6位的英文或数字");
			}else{
				uname.setCustomValidity("");
			}
			var telephone=document.getElementById("telephone");
			if(telephone.validity.valueMissing==true){
				telephone.setCustomValidity("电话号码不能为空！");
			}else if(telephone.validity.patternMismatch==true){
				telephone.setCustomValidity("手机号码不存在！");
			}else{
				telephone.setCustomValidity("");
			}
			var short=document.getElementById("short");
			if(short.validity.valueMissing==true){
				short.setCustomValidity("请填写手机验证码");
			}else{
				short.setCustomValidity("");
			}
			var pass=document.getElementById("pass");
			
		})
	}
	checkFormData();
	//获取随机的验证码
	function getCheckNumber(){
		$("#getNo").click(function(){
			var num="";
			var telephone=$("#telephone");
			if(telephone.val()==""||telephone.val()==null){
				alert("请先填写手机号！");
			}else{
				for(var i=0;i<6;i++){
					num+=Math.round(Math.random()*10);
				}
				$(this).prev().val(num);
			}
		})
	}
	getCheckNumber();
})
