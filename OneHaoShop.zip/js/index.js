$(function(){
	//图片轮播
	function changeImg(){
		var $imgs=$(".scroll_img li");
		var $txt=$(".scroll_tex li");
		var index=0;
		var flag=false;
		$txt.first().css({"background":"#000","color":"#fff"});
		$($txt).mouseenter(function(){
			flag=true;
			index=$(this).index();
			$(this).css({"background":"#000","color":"#fff"}).siblings().css({"background":"#fff","color":"#000"});
			$($imgs[index]).fadeIn().siblings().fadeOut();
		}).mouseout(function(){
			flag=false;
		})
		setInterval(function(){
			if(flag) return;
			index++;
			if(index>$txt.length-1) index=0;
			$($txt[index]).css({"background":"#000","color":"#fff"}).siblings().css({"background":"#fff","color":"#000"});
			$($imgs[index]).fadeIn().siblings().fadeOut();
		},4000);
	}
	changeImg();
	//设置倒计时
	function setCountDown(){
		var offset=$("#supertime").offset();
		$("#time").css({"top":offset.top+170,"left":offset.left+30});
		var hour=3;
		var minues=12;
		var second=60;
		$("#hour").html("0"+hour);
		$("#minute").html(minues);
		$("#second").html(second);
		setInterval(function(){
			if(second>0){
				second--;
				if(second<10){
					$("#second").html("0"+second);
				}else{
					$("#second").html(second);
				}
				if(second==0){
					minues--;
					if(minues<10){
						$("#minute").html("0"+minues);
					}else{
						$("#minute").html(minues);
					}
					second=60;
					if(minues==0){
						hour--;
						minues=60;
						if(hour==0){
							return;
						}
						$("#hour").html("0"+hour);
					}
				}
			}
		},1000);
	}
	setCountDown();
	//鼠标放上与全部分类时，显示的二级菜单
	function showList(){
		var $list=$(".bnav .bg_yes");
		var offset=$list.offset();
		$list.mouseenter(function(){
			$(this).children("div").css({"top":offset.top+40,"left":offset.left,"z-index":1}).show();
		}).mouseleave(function(){
			$(this).children("div").css({"top":offset.top+40,"left":offset.left,"z-index":0}).hide();
		})
	}
	showList();
})
